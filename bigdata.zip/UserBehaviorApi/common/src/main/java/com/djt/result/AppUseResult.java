package com.djt.result;

import java.util.Map;

public class AppUseResult extends BaseResult
{

  @Override
  public Map<String, Object> getData()
  {
    return null;
  }

  @Override
  public void setData(Object data)
  {
  }
}
