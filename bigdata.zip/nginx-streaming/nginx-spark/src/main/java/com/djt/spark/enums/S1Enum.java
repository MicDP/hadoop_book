package com.djt.spark.enums;

public enum S1Enum
{
  BIZTYPE,
  IPS,
  REMOTE_USER,
  TIME,
  URL,
  STATUS,
  BODY_BYTES_SEND,
  REFERER,
  AGENT,
  REQUEST_TIME,
  UPSTREAM_RESPONSE_TIME,
  REMOTE_ADDR
}
